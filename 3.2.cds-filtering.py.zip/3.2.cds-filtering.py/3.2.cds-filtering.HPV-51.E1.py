from collections import defaultdict

inf = open('./3.cds/HPV-51/HPV-51.E1.cds.fasta', 'r')
outf = open('./3.cds/HPV-51/HPV-51.E1.cds.filtered.fasta', 'w')
# inf = open('./3.cds/HPV-51/HPV-51.complete.cds.fasta', 'r')
# outf = open('./3.cds/HPV-51/HPV-51.complete.E1.cds.filtered.fasta', 'w')
exp_n = [1902, 1902]

seq = {}
for line in inf.readlines():
	# print(line)
	if line.startswith('>'):
		name = line.strip().strip('>')
		seq[name] = ''
	else:                
		seq[name] += line.strip()

total_n = 0
pos_n = 0
neg_n = 0
pos_count_dict = defaultdict(int)
neg_count_dict = defaultdict(int)
for key in seq.keys():
	total_n += 1
	info = key.split(' ')
	length = info[3].split(':')[1]
	if '+' in info[1]:
		pos_n += 1
		pos_count_dict[length] += 1
	else:
		neg_n += 1
		neg_count_dict[length] += 1

if len(pos_count_dict) != 0:
	pos_id_max = max(pos_count_dict, key=pos_count_dict.get)
	pos_count_max = pos_count_dict[pos_id_max]
else:
	pos_id_max = 'NA'
	pos_count_max = 0
if len(neg_count_dict) != 0:
	neg_id_max = max(neg_count_dict, key=neg_count_dict.get)
	neg_count_max = neg_count_dict[neg_id_max]
else:
	neg_id_max = 'NA'
	neg_count_max = 0

if pos_count_max > neg_count_max:
	stand = '+'
	id_max = pos_id_max
	count_max = pos_count_max
else:
	stand = '-'
	id_max = neg_id_max
	count_max = neg_count_max

# pos_count_dict = sorted(pos_count_dict.items(), key=lambda d: d[0], reverse=False)
# neg_count_dict = sorted(neg_count_dict.items(), key=lambda d: d[0], reverse=False)
pos_count_dict = sorted(pos_count_dict.items(), key=lambda d: d[1], reverse=True)
neg_count_dict = sorted(neg_count_dict.items(), key=lambda d: d[1], reverse=True)

print('Number of seqs: ' + str(total_n))
print('--------------------')
print('Number of +stand seqs: ' + str(pos_n))
print(pos_count_dict)
print(pos_id_max, pos_count_max)
print('--------------------')
print('Number of -stand seqs: ' + str(neg_n))
print(neg_count_dict)
print(neg_id_max, neg_count_max)
print('--------------------')
print('Summary:', stand, id_max, count_max)

n = 0
for key in seq.keys():
	info = key.split(' ')
	# print(info)
	# if stand in info[1] and str(id_max) in info[3]:
	# if stand in info[1] and str(exp_n) in info[3]:
	length = int(info[3].strip('length:'))
	# print(length)
	if '+' in info[1] and length >= exp_n[0] and length <= exp_n[1]:
	# if '+' in info[1] and str(exp_n) in info[3]:
		n += 1
		# print(info)
		outf.write('>'+ key + '\n' + seq[key] + '\n')

inf.close()
outf.close()

print('--------------------')
print('Summary:', stand, id_max, count_max, exp_n, n)

